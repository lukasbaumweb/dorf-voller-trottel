ASSET PACK CONTENTS

- Five human characters
- Two animal drawings
- A bunch of office themed assets (furniture, computers, plants, decor, etc.)

Assets are provided in PNG and Aseprite formats with an example scene.


LICENSE INFORMATION

This is released under the Creative Commons Public Domain Dedication License (aka CC0 or CC Zero), and can be read here: https://creativecommons.org/publicdomain/zero/1.0/

No attribution is required but it is greatly appreciated =).


DONATIONS

If you like the assets please consider leaving a donation.

Kindly,

2dPig