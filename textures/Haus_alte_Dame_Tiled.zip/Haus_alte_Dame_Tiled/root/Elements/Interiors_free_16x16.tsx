<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Interiors_free_16x16" tilewidth="16" tileheight="16" tilecount="1424" columns="16">
 <image source="../../../../../../../OneDrive-BildungsCentrumderWirtschaftgemeinnützigeGesellschaftmbH/Uni/Seme6/Anwendungsprojekt/Haus_alte_Dame_Tiled/root/Elements/PNG/Interiors_free_16x16.png" width="256" height="1424"/>
</tileset>
