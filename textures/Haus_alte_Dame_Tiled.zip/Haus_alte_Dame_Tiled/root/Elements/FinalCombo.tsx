<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="FinalCombo" tilewidth="16" tileheight="16" tilecount="840" columns="30">
 <image source="../../../../../../../../../Downloads/FinalCombo.png" width="480" height="448"/>
</tileset>
