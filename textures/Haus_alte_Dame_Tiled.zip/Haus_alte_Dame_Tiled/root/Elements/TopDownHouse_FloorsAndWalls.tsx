<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="TopDownHouse_FloorsAndWalls" tilewidth="16" tileheight="16" tilecount="162" columns="18">
 <image source="../../../../../../../OneDrive-BildungsCentrumderWirtschaftgemeinnützigeGesellschaftmbH/Uni/Seme6/Anwendungsprojekt/Haus_alte_Dame_Tiled/root/Elements/PNG/TopDownHouse_FloorsAndWalls.png" width="288" height="144"/>
</tileset>
