<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="PC" tilewidth="16" tileheight="16" tilecount="160" columns="16">
 <image source="../../../../Downloads/PixelOffice/PixelOfficeAssets.png" width="256" height="160"/>
</tileset>
