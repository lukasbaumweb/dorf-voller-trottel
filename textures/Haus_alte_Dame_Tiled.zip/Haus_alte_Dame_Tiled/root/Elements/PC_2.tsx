<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="PC_2" tilewidth="16" tileheight="16" tilecount="294" columns="14">
 <image source="PNG/Haus_2/Haus_2.png" width="224" height="344"/>
</tileset>
