<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="TopDownHouse_SmallItems" tilewidth="16" tileheight="16" tilecount="64" columns="8">
 <image source="../../../../../../../OneDrive-BildungsCentrumderWirtschaftgemeinnützigeGesellschaftmbH/Uni/Seme6/Anwendungsprojekt/Haus_alte_Dame_Tiled/root/Elements/PNG/TopDownHouse_SmallItems.png" width="128" height="128"/>
</tileset>
