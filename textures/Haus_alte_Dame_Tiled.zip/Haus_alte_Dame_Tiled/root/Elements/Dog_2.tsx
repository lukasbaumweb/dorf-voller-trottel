<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Dog" tilewidth="8" tileheight="8" tilecount="72" columns="12">
 <image source="Animal /2 Dog 2/Hurt.png" width="96" height="48"/>
</tileset>
