<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Dog" tilewidth="16" tileheight="16" tilecount="36" columns="12">
 <image source="Animal_/2 Dog 2/Idle.png" width="192" height="48"/>
</tileset>
