<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Baum" tilewidth="16" tileheight="16" tilecount="64" columns="8">
 <image source="PNG/Baum/BasicPlains-tileset-Ver.2_by_AxulArt.png" width="128" height="128"/>
</tileset>
