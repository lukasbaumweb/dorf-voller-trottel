 __  __           _                   __  __             
|  \/  |         | |                 |  \/  |            
| \  / | ___   __| | ___ _ __ _ __   | \  / | __ _ _ __  
| |\/| |/ _ \ / _` |/ _ \ '__| '_ \  | |\/| |/ _` | '_ \ 
| |  | | (_) | (_| |  __/ |  | | | | | |  | | (_| | |_) |
|_|  |_|\___/ \__,_|\___|_|  |_| |_| |_|  |_|\__,_| .__/ 
                                                  | |    
                                                  |_|    
 _____           _    
|  __ \         | |   
| |__) |_ _  ___| | __
|  ___/ _` |/ __| |/ /
| |  | (_| | (__|   < 
|_|   \__,_|\___|_|\_\
                      

Thank you so much for supporting us!

This pack contains five free stylized maps with place names and frames. They are ready to be used right out of the box. 

The free version is only available with the stylized overlay, place names, a square grid, and our branding present. If you want more variations, no branding, and more maps, consider upgrading to the premium version.

This pack is licensed under Attribution-NoDerivatives 4.0 International  (CC BY-ND 4.0). Consult the license document for more information.